This guide applies to all current agent versions (both FIN and PUB versions)

Windows:
- enter into agent updater home directory (usually in C:\Program Files (x86)\NBP\agent_controller_windows\agent_controller_windows\)
- stop agent command: "agent.bat stop"
- start agent command: "agent.bat start"
- restart agent: "agent.bat stop" and "agent.bat start"
- uninstall agent: "agent.bat stop" and "agent.bat uninstall"

Linux:
- enter into agent updater home directory (usually in /home1/nbpmon/agent_controller_linux)
- please copy start_agent.sh, stop_agent.sh, restart_agent.sh, uninstall_agent.sh into agent updater home directory(/home1/nbpmon/agent_controller_linux)
- stop agent: "./stop_agent.sh"
- start agent: "./start_agent.sh"
- restart agent: "./restart_agent.sh"
- uninstall agent: "./uninstall_agent.sh"