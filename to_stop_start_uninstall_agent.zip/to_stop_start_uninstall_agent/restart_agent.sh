#!/bin/bash

AGENT_ROOT=$(cd `dirname $0`; pwd)

$AGENT_ROOT/stop_agent.sh
sleep 1s
$AGENT_ROOT/start_agent.sh